//
//  XMPPvCardTempCoreDataStorageObject.m
//  XEP-0054 vCard-temp
//
//  Originally created by Eric Chamberlain on 3/18/11.
//

#import "XMPPvCardTempCoreDataStorageObject.h"
#import "XMPPvCardCoreDataStorageObject.h"


@implementation XMPPvCardTempCoreDataStorageObject

@dynamic vCardTemp;
@dynamic vCard;

@end
