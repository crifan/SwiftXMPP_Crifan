SwiftXMPP
=========

basic XMPP client for iOS written in swift using XMPPFramework

##Initialization
1. `git clone https://github.com/nemesit/SwiftXMPP.git`
2. `cd SwiftXMPP`
3. `git submodule update --init --recursive && git submodule foreach git pull origin master`
4. `mv XMPPFramework/Sample_XMPPFramework.h XMPPFramework/XMPPFramework.h`
